After deploying the application springsecurity2 :

	To access the common page, enter the following URL: 
	http://localhost:8080/springsecurity2/secure/main/common
	To access the admin page, enter the following URL: 
	http://localhost:8080/springsecurity2/secure/main/admin
	To login, enter the following URL: 
	http://localhost:8080/springsecurity2/secure/auth/login
	To logout, enter the following URL: 
	http://localhost:8080/springsecurity2/secure/auth/logout
	
	
